# API PHP de autenticación para LSM Aprende

La API usa PHP, MariaDB/MySQL y Brevo. Conserva el registro, inicio/cierre de sesión, restauración de sesión y recuperación por código que consume la app Expo.

## Antes de empezar

- Confirma en **Consumo/Offer** de Alwaysdata el plan asociado a tu cuenta. En la pantalla de alta que compartiste estaba seleccionado **Small**, no Free; comprueba el precio en tu panel antes de continuar.
- Crea una cuenta gratuita de [Brevo](https://www.brevo.com/), verifica la dirección desde la que se enviarán los mensajes y genera una clave API.
- Nunca compartas contraseñas, claves API, códigos de acceso ni datos privados de la base en el chat.

Alwaysdata ofrece PHP, bases administradas MariaDB/MySQL y certificados SSL automáticos. Antes de conectar la app, comprueba en la cuenta que la versión de PHP tenga `pdo_mysql` y `openssl`, y que PHP permita llamadas HTTPS salientes a `api.brevo.com`.

## Preparar la API

1. El sitio PHP y la base MySQL/MariaDB ya están creados. El dominio que compartiste es `https://lsm-aprende-api.alwaysdata.net`; verifica en el panel si tiene HTTPS activo.
2. En la configuración PHP selecciona PHP 8.2 o superior y confirma las extensiones `pdo_mysql` y `openssl`.
3. En tu computadora, desde la carpeta `api`, instala las dependencias:

   ```bash
   composer install --no-dev --optimize-autoloader
   ```

   Si Alwaysdata no ofrece Composer en tu plan, sube también la carpeta `api/vendor` creada localmente.
4. Sube el archivo `api-deploy.zip` que se preparó en la carpeta del proyecto y descomprímelo en la carpeta personal de la cuenta usando SFTP/SSH o el administrador de archivos del panel. Debe quedar `api/public/index.php` y `api/vendor/autoload.php`. Configura el document root del sitio en `/home/lsm-aprende-api/api/public`. Mantén `api/.env` fuera de la carpeta pública.
5. La base `lsm-aprende-api_auth` ya está creada y el archivo [`database.sql`](./database.sql) ya se importó. No la importes otra vez. Usa los detalles del panel: host `mysql-lsm-aprende-api.alwaysdata.net`, puerto `3306`, base `lsm-aprende-api_auth` y el usuario MySQL que figura para esa base.
6. Crea `api/.env` en el servidor a partir de [`api/.env.example`](./.env.example). Sustituye los valores de ejemplo por la configuración privada del panel y Brevo:

   ```env
   APP_ENV=production
   APP_NAME=LSM Aprende
   APP_ALLOWED_ORIGIN=
   DB_HOST=host-de-base-indicado-por-alwaysdata
   DB_PORT=3306
   DB_NAME=nombre-completo-de-la-base
   DB_USER=usuario-completo-de-la-base
   DB_PASSWORD=contraseña-de-la-base
   BREVO_API_KEY=clave-privada-de-brevo
   MAIL_FROM_ADDRESS=remitente-verificado
   MAIL_FROM_NAME=LSM Aprende
   ```

   Usa exactamente los datos que muestra tu cuenta; no supongas que el host de la base es `127.0.0.1`. La clave de Brevo debe quedarse únicamente en `api/.env` del servidor.
7. Comprueba `https://TU-SITIO/health`; debe responder `{"data":{"status":"ok"}}`. Luego revisa `https://TU-SITIO/`, que también comprueba la conexión a la base.
8. Desde el inicio de sesión de la app, prueba registro e inicio de sesión. Después solicita recuperación de contraseña y confirma que el código llegue desde Brevo. Si no llega, comprueba el remitente verificado y que Alwaysdata permita la llamada HTTPS a Brevo.
9. Solo después de confirmar la API, configura la variable en el `.env` de Expo, en la raíz del proyecto:

   ```env
   EXPO_PUBLIC_API_URL=https://TU-SITIO
   ```

   Usa la URL real, con HTTPS y sin `/health`. Si la app web se publica en otro origen, configura `APP_ALLOWED_ORIGIN` con ese origen exacto. En Android/iOS nativos no se requiere CORS.
10. Reinicia Expo para que lea la URL nueva:

   ```bash
   npx expo start --clear
   ```

## Rutas

- `POST /auth/register`: `{ "full_name", "email", "password" }`
- `POST /auth/login`: `{ "email", "password" }`
- `GET /auth/me`: sesión actual; requiere encabezado bearer token
- `POST /auth/logout`: revoca la sesión; requiere bearer token
- `POST /auth/password/forgot`: `{ "email" }`; respuesta genérica para no revelar si existe la cuenta
- `POST /auth/password/reset`: `{ "email", "code", "password" }`
- `GET /health`: estado de PHP sin requerir base configurada

Las contraseñas y códigos se almacenan usando `password_hash`; los tokens de sesión se guardan como hashes SHA-256. Los códigos de recuperación vencen en diez minutos, permiten hasta cinco intentos y solo se usan una vez. Las sesiones existentes se revocan al cambiar la contraseña.

## Nota de plataformas anteriores

InfinityFree gratuito bloquea llamadas de clientes móviles a sitios/API, por lo que Expo Go no puede usarlo. Cloudflare Workers tampoco se usa: su implementación de Web Crypto limita PBKDF2 a 100.000 iteraciones, insuficiente para la política de hash seguro de esta API. El Worker y la base D1 de prueba se retiraron. `supabase/schema.sql` también es antiguo y no se importa en MariaDB.
