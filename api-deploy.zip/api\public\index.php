<?php
declare(strict_types=1);

require dirname(__DIR__) . '/vendor/autoload.php';

Dotenv\Dotenv::createImmutable(dirname(__DIR__))->safeLoad();

final class ApiException extends RuntimeException
{
    public function __construct(string $message, public readonly int $status)
    {
        parent::__construct($message);
    }
}

function respond(int $status, array $payload): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function database(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $host = $_ENV['DB_HOST'] ?? '';
    $port = $_ENV['DB_PORT'] ?? '3306';
    $name = $_ENV['DB_NAME'] ?? '';
    $user = $_ENV['DB_USER'] ?? '';
    $password = $_ENV['DB_PASSWORD'] ?? '';
    if ($host === '' || $name === '' || $user === '' || $password === '') {
        throw new ApiException('La API no está configurada correctamente.', 503);
    }

    $pdo = new PDO(
        "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4",
        $user,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ],
    );
    return $pdo;
}

function requestBody(): array
{
    $body = json_decode(file_get_contents('php://input'), true);
    if (!is_array($body)) {
        throw new ApiException('El cuerpo de la solicitud debe ser JSON válido.', 400);
    }
    return $body;
}

function requiredString(array $body, string $key): string
{
    $value = $body[$key] ?? null;
    if (!is_string($value)) {
        throw new ApiException('Completa los campos requeridos.', 400);
    }
    return trim($value);
}

function requiredPassword(array $body, string $key): string
{
    $value = $body[$key] ?? null;
    if (!is_string($value)) {
        throw new ApiException('Completa los campos requeridos.', 400);
    }
    return $value;
}

function normalizeEmail(string $email): string
{
    $normalized = strtolower(trim($email));
    if (strlen($normalized) > 254 || filter_var($normalized, FILTER_VALIDATE_EMAIL) === false) {
        throw new ApiException('Escribe un correo electrónico válido.', 400);
    }
    return $normalized;
}

function validatePassword(string $password): void
{
    $length = preg_match_all('/./us', $password);
    if ($length === false || $length < 8 || strlen($password) > 72) {
        throw new ApiException('La contraseña debe tener entre 8 y 72 caracteres.', 400);
    }
}

function utf8Length(string $value): int
{
    $length = preg_match_all('/./us', $value);
    if ($length === false) {
        throw new ApiException('El texto contiene caracteres no válidos.', 400);
    }
    return $length;
}

function enforceRateLimit(PDO $pdo, string $action, string $identity, int $limit, int $windowSeconds): void
{
    $bucketStart = intdiv(time(), $windowSeconds) * $windowSeconds;
    $identityHash = hash('sha256', $identity);
    $statement = $pdo->prepare(
        'INSERT INTO auth_rate_limits (action_name, identity_hash, bucket_start, hits)
         VALUES (?, ?, ?, 1)
         ON DUPLICATE KEY UPDATE hits = hits + 1'
    );
    $statement->execute([$action, $identityHash, $bucketStart]);

    $count = $pdo->prepare(
        'SELECT hits FROM auth_rate_limits
         WHERE action_name = ? AND identity_hash = ? AND bucket_start = ?'
    );
    $count->execute([$action, $identityHash, $bucketStart]);
    if ((int) $count->fetchColumn() > $limit) {
        throw new ApiException('Demasiados intentos. Espera un momento e inténtalo de nuevo.', 429);
    }
}

function clientIp(): string
{
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

function requireMailConfiguration(): void
{
    $requiredConfig = [
        'BREVO_API_KEY',
        'MAIL_FROM_ADDRESS', 'MAIL_FROM_NAME',
    ];
    foreach ($requiredConfig as $key) {
        if (($_ENV[$key] ?? '') === '') {
            throw new ApiException('El servicio de correo todavía no está configurado.', 503);
        }
    }
}

function publicUser(array $row): array
{
    return [
        'id' => (int) $row['id'],
        'email' => $row['email'],
        'full_name' => $row['full_name'],
    ];
}

function createSession(PDO $pdo, array $user): array
{
    $token = bin2hex(random_bytes(32));
    $statement = $pdo->prepare(
        'INSERT INTO auth_sessions (user_id, token_hash, expires_at)
         VALUES (?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL 30 DAY))'
    );
    $statement->execute([
        $user['id'],
        hash('sha256', $token),
    ]);

    return ['token' => $token, 'user' => publicUser($user)];
}

function bearerToken(): string
{
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/^Bearer ([a-f0-9]{64})$/i', $header, $matches)) {
        throw new ApiException('La sesión no es válida. Inicia sesión de nuevo.', 401);
    }
    return strtolower($matches[1]);
}

function authenticatedUser(PDO $pdo): array
{
    $statement = $pdo->prepare(
        'SELECT u.id, u.email, u.full_name
         FROM auth_sessions s
         INNER JOIN users u ON u.id = s.user_id
         WHERE s.token_hash = ? AND s.expires_at > UTC_TIMESTAMP()
         LIMIT 1'
    );
    $statement->execute([hash('sha256', bearerToken())]);
    $user = $statement->fetch();
    if (!$user) {
        throw new ApiException('La sesión venció. Inicia sesión de nuevo.', 401);
    }
    return $user;
}

function sendResetEmail(string $email, string $code): void
{
    requireMailConfiguration();

    $appName = htmlspecialchars($_ENV['APP_NAME'] ?? 'LSM Aprende', ENT_QUOTES, 'UTF-8');
    $payload = json_encode([
        'sender' => [
            'name' => $_ENV['MAIL_FROM_NAME'],
            'email' => $_ENV['MAIL_FROM_ADDRESS'],
        ],
        'to' => [['email' => $email]],
        'subject' => 'Código para recuperar tu contraseña',
        'htmlContent' => "<p>Usa este código para restablecer tu contraseña de {$appName}:</p>"
            . "<h2 style=\"letter-spacing:8px\">{$code}</h2>"
            . '<p>El código vence en 10 minutos. Si no solicitaste este cambio, ignora este correo.</p>',
        'textContent' => "Tu código para recuperar la contraseña es {$code}. Vence en 10 minutos.",
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($payload === false) {
        throw new ApiException('No se pudo preparar el correo de recuperación.', 500);
    }

    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => implode("\r\n", [
                'Accept: application/json',
                'Content-Type: application/json',
                'api-key: ' . $_ENV['BREVO_API_KEY'],
            ]),
            'content' => $payload,
            'timeout' => 15,
            'ignore_errors' => true,
        ],
    ]);
    $response = @file_get_contents('https://api.brevo.com/v3/smtp/email', false, $context);
    $statusLine = $http_response_header[0] ?? '';
    if ($response === false || !preg_match('/\s2\d{2}\s/', $statusLine)) {
        error_log('Password recovery email delivery failed; Brevo request did not succeed.');
        throw new ApiException('No se pudo enviar el correo. Inténtalo de nuevo más tarde.', 503);
    }
}

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowedOrigin = $_ENV['APP_ALLOWED_ORIGIN'] ?? '';
if ($origin !== '' && $allowedOrigin !== '' && hash_equals($allowedOrigin, $origin)) {
    header('Access-Control-Allow-Origin: ' . $allowedOrigin);
    header('Vary: Origin');
}
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$path = '/' . trim(preg_replace('#^/index\.php#', '', $path), '/');
if ($method === 'GET' && $path === '/health') {
    respond(200, ['data' => ['status' => 'ok']]);
}

try {
    $pdo = database();
    if ($path === '/') {
        $path = '/';
    }

    if ($method === 'GET' && $path === '/') {
        respond(200, ['data' => ['status' => 'ok']]);
    }

    if ($method === 'POST' && $path === '/auth/register') {
        $body = requestBody();
        $email = normalizeEmail(requiredString($body, 'email'));
        $fullName = requiredString($body, 'full_name');
        $password = requiredPassword($body, 'password');
        if ($fullName === '' || utf8Length($fullName) > 120) {
            throw new ApiException('El nombre debe tener entre 1 y 120 caracteres.', 400);
        }
        validatePassword($password);
        enforceRateLimit($pdo, 'register-ip', clientIp(), 10, 900);

        try {
            $insert = $pdo->prepare(
                'INSERT INTO users (email, full_name, password_hash) VALUES (?, ?, ?)'
            );
            $insert->execute([$email, $fullName, password_hash($password, PASSWORD_DEFAULT)]);
        } catch (PDOException $error) {
            if ($error->getCode() === '23000') {
                throw new ApiException('No se pudo crear la cuenta con ese correo. Verifica si ya está registrado.', 409);
            }
            throw $error;
        }
        $user = [
            'id' => (int) $pdo->lastInsertId(),
            'email' => $email,
            'full_name' => $fullName,
        ];
        respond(201, ['data' => createSession($pdo, $user)]);
    }

    if ($method === 'POST' && $path === '/auth/login') {
        $body = requestBody();
        $email = normalizeEmail(requiredString($body, 'email'));
        $password = requiredPassword($body, 'password');
        enforceRateLimit($pdo, 'login-ip', clientIp(), 10, 900);
        $statement = $pdo->prepare(
            'SELECT id, email, full_name, password_hash FROM users WHERE email = ? LIMIT 1'
        );
        $statement->execute([$email]);
        $user = $statement->fetch();
        if (!$user || !password_verify($password, $user['password_hash'])) {
            throw new ApiException('Correo o contraseña incorrectos.', 401);
        }
        respond(200, ['data' => createSession($pdo, $user)]);
    }

    if ($method === 'GET' && $path === '/auth/me') {
        respond(200, ['data' => ['user' => publicUser(authenticatedUser($pdo))]]);
    }

    if ($method === 'POST' && $path === '/auth/logout') {
        $statement = $pdo->prepare('DELETE FROM auth_sessions WHERE token_hash = ?');
        $statement->execute([hash('sha256', bearerToken())]);
        respond(200, ['data' => null]);
    }

    if ($method === 'POST' && $path === '/auth/password/forgot') {
        $email = normalizeEmail(requiredString(requestBody(), 'email'));
        requireMailConfiguration();
        enforceRateLimit($pdo, 'recovery-ip', clientIp(), 5, 3600);
        enforceRateLimit($pdo, 'recovery-email', $email, 3, 3600);
        $statement = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $statement->execute([$email]);
        $user = $statement->fetch();
        if ($user) {
            $userId = (int) $user['id'];
            $lastRequest = $pdo->prepare(
                'SELECT created_at FROM password_reset_codes
                 WHERE user_id = ? AND created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL 60 SECOND)
                 ORDER BY created_at DESC LIMIT 1'
            );
            $lastRequest->execute([$userId]);
            if (!$lastRequest->fetch()) {
                $code = (string) random_int(100000, 999999);
                $insertCode = $pdo->prepare(
                    'INSERT INTO password_reset_codes (user_id, code_hash, expires_at)
                     VALUES (?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL 10 MINUTE))'
                );
                $insertCode->execute([$userId, password_hash($code, PASSWORD_DEFAULT)]);
                $resetCodeId = (int) $pdo->lastInsertId();
                try {
                    sendResetEmail($email, $code);
                } catch (ApiException $error) {
                    $deleteCode = $pdo->prepare('DELETE FROM password_reset_codes WHERE id = ?');
                    $deleteCode->execute([$resetCodeId]);
                    throw $error;
                }
            }
        }
        respond(200, ['data' => ['message' => 'Si el correo está registrado, recibirás un código de recuperación.']]);
    }

    if ($method === 'POST' && $path === '/auth/password/reset') {
        $body = requestBody();
        $email = normalizeEmail(requiredString($body, 'email'));
        $code = requiredString($body, 'code');
        $password = requiredPassword($body, 'password');
        enforceRateLimit($pdo, 'reset-ip', clientIp(), 10, 900);
        if (!preg_match('/^\d{6}$/', $code)) {
            throw new ApiException('El código debe contener 6 dígitos.', 400);
        }
        validatePassword($password);

        $pdo->beginTransaction();
        $findUser = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1 FOR UPDATE');
        $findUser->execute([$email]);
        $user = $findUser->fetch();
        if (!$user) {
            $pdo->rollBack();
            throw new ApiException('El código no es válido o ya venció.', 400);
        }

        $findCode = $pdo->prepare(
            'SELECT id, code_hash, attempts FROM password_reset_codes
             WHERE user_id = ? AND used_at IS NULL AND expires_at > UTC_TIMESTAMP()
             ORDER BY created_at DESC LIMIT 1 FOR UPDATE'
        );
        $findCode->execute([(int) $user['id']]);
        $reset = $findCode->fetch();
        if (!$reset || (int) $reset['attempts'] >= 5) {
            $pdo->rollBack();
            throw new ApiException('El código no es válido o ya venció. Solicita uno nuevo.', 400);
        }
        if (!password_verify($code, $reset['code_hash'])) {
            $attempts = $pdo->prepare('UPDATE password_reset_codes SET attempts = attempts + 1 WHERE id = ?');
            $attempts->execute([(int) $reset['id']]);
            $pdo->commit();
            throw new ApiException('El código no es válido o ya venció.', 400);
        }

        $update = $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
        $update->execute([password_hash($password, PASSWORD_DEFAULT), (int) $user['id']]);
        $consume = $pdo->prepare(
            'UPDATE password_reset_codes SET used_at = UTC_TIMESTAMP() WHERE user_id = ? AND used_at IS NULL'
        );
        $consume->execute([(int) $user['id']]);
        $deleteSessions = $pdo->prepare('DELETE FROM auth_sessions WHERE user_id = ?');
        $deleteSessions->execute([(int) $user['id']]);
        $pdo->commit();
        respond(200, ['data' => ['message' => 'Contraseña actualizada.']]);
    }

    respond(404, ['error' => 'La ruta solicitada no existe.']);
} catch (ApiException $error) {
    respond($error->status, ['error' => $error->getMessage()]);
} catch (Throwable $error) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('Authentication API internal error: ' . get_class($error));
    respond(500, ['error' => 'Ocurrió un error interno. Inténtalo de nuevo más tarde.']);
}
